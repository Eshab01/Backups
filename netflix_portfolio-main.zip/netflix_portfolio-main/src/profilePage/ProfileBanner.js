import './ProfileBanner.css';
import PlayButton from '../components/PlayButton.js';
import MoreInfoButton from '../components/MoreInfoButton.js';
import { getProfileBanner } from '../queries/getProfileBanner.js';

let bannerData = null;

async function fetchData() {
  bannerData = await getProfileBanner();
  updateBanner();
}

function handlePlayClick() {
  window.open(bannerData.resumeLink.url, '_blank');
}

function handleLinkedinClick() {
  window.open(bannerData.linkedinLink, '_blank');
}

function updateBanner() {
  const banner = document.querySelector('.profile-banner');
  if (!banner) return;

  const headline = banner.querySelector('#headline');
  if (headline) headline.textContent = bannerData.headline;

  const description = banner.querySelector('.banner-description');
  if (description) description.textContent = bannerData.profileSummary;
}

function ProfileBanner() {
  const banner = document.createElement('div');
  banner.className = 'profile-banner';

  const content = document.createElement('div');
  content.className = 'banner-content';

  const headline = document.createElement('h1');
  headline.className = 'banner-headline';
  headline.id = 'headline';
  content.appendChild(headline);

  const description = document.createElement('p');
  description.className = 'banner-description';
  content.appendChild(description);

  const buttons = document.createElement('div');
  buttons.className = 'banner-buttons';

  const playButton = PlayButton({ onClick: handlePlayClick, label: "Resume" });
  buttons.appendChild(playButton);

  const moreInfoButton = MoreInfoButton({ onClick: handleLinkedinClick, label: "Linkedin" });
  buttons.appendChild(moreInfoButton);

  content.appendChild(buttons);
  banner.appendChild(content);

  fetchData();
  return banner;
}

export default ProfileBanner;
