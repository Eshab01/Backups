import './ContinueWatching.css';

const continueWatchingConfig = {
  recruiter: [
    { title: "Music", imgSrc: "https://picsum.photos/id/1025/300/200", link: "/music" },
    { title: "Reading", imgSrc: "https://picsum.photos/id/1026/300/200", link: "/reading" },
    { title: "Blogs", imgSrc: "https://picsum.photos/id/1027/300/200", link: "/blogs" },
    { title: "Contact Me", imgSrc: "https://picsum.photos/id/1029/300/200", link: "/contact-me" }
  ],
  developer: [
    { title: "Music", imgSrc: "https://picsum.photos/id/1025/300/200", link: "/music" },
    { title: "Reading", imgSrc: "https://picsum.photos/id/1026/300/200", link: "/reading" },
    { title: "Blogs", imgSrc: "https://picsum.photos/id/1027/300/200", link: "/blogs" },
    { title: "Certifications", imgSrc: "https://picsum.photos/id/1028/300/200", link: "/certifications" },
    { title: "Contact Me", imgSrc: "https://picsum.photos/id/1029/300/200", link: "/contact-me" }
  ],
  stalker: [
    { title: "Reading", imgSrc: "https://picsum.photos/id/1026/300/200", link: "/reading" },
    { title: "Blogs", imgSrc: "https://picsum.photos/id/1027/300/200", link: "/blogs" },
    { title: "Contact Me", imgSrc: "https://picsum.photos/id/1029/300/200", link: "/contact-me" }
  ],
  adventure: [
    { title: "Music", imgSrc: "https://picsum.photos/id/1025/300/200", link: "/music" },
    { title: "Reading", imgSrc: "https://picsum.photos/id/1026/300/200", link: "/reading" },
    { title: "Certifications", imgSrc: "https://picsum.photos/id/1028/300/200", link: "/certifications" },
    { title: "Contact Me", imgSrc: "https://picsum.photos/id/1029/300/200", link: "/contact-me" }
  ]
};

function ContinueWatching({ profile }) {
  const continueWatching = continueWatchingConfig[profile];

  const container = document.createElement('div');
  container.className = 'continue-watching-row';

  const title = document.createElement('h2');
  title.className = 'row-title';
  title.textContent = `Continue Watching for ${profile}`;
  container.appendChild(title);

  const cardRow = document.createElement('div');
  cardRow.className = 'card-row';

  continueWatching.forEach((pick, index) => {
    const card = document.createElement('a');
    card.href = pick.link;
    card.className = 'pick-card';

    const img = document.createElement('img');
    img.src = pick.imgSrc;
    img.alt = pick.title;
    img.className = 'pick-image';
    card.appendChild(img);

    const overlay = document.createElement('div');
    overlay.className = 'overlay';

    const label = document.createElement('div');
    label.className = 'pick-label';
    label.textContent = pick.title;
    overlay.appendChild(label);

    card.appendChild(overlay);
    cardRow.appendChild(card);
  });

  container.appendChild(cardRow);
  return container;
}

export default ContinueWatching;
