import './ProfilePage.css';
import ProfileBanner from './ProfileBanner.js';
import TopPicksRow from './TopPicksRow.js';
import ContinueWatching from './ContinueWatching.js';

function getProfileType(profileName) {
  const validProfiles = ['recruiter', 'developer', 'stalker', 'adventure'];
  return validProfiles.includes(profileName) ? profileName : 'recruiter';
}

function ProfilePage() {
  const urlParams = new URLSearchParams(window.location.search);
  const backgroundGif = urlParams.get('backgroundGif') || "https://media.giphy.com/media/xT9IgzoKnwFNmISR8I/giphy.gif";
  const profileName = window.location.pathname.split('/').pop();
  const profile = getProfileType(profileName);

  const container = document.createElement('div');
  container.className = 'profile-page';
  container.style.backgroundImage = `url(${backgroundGif})`;

  const profileBanner = ProfileBanner();
  container.appendChild(profileBanner);

  const topPicksRow = TopPicksRow({ profile });
  container.appendChild(topPicksRow);

  const continueWatching = ContinueWatching({ profile });
  container.appendChild(continueWatching);

  return container;
}

export default ProfilePage;
