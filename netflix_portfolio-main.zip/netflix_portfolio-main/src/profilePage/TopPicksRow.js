import './TopPicksRow.css';

const topPicksConfig = {
  recruiter: [
    { title: "Work Permit", imgSrc: "https://picsum.photos/seed/workpermit/250/200", route: "/work-permit" },
    { title: "Skills", imgSrc: "https://picsum.photos/seed/skills/250/200", route: "/skills" },
    { title: "Experience", imgSrc: "https://picsum.photos/seed/workexperience/250/200", route: "/work-experience" },
    { title: "Certifications", imgSrc: "https://picsum.photos/seed/certifications/250/200", route: "/certifications" },
    { title: "Recommendations", imgSrc: "https://picsum.photos/seed/recommendations/250/200", route: "/recommendations" },
    { title: "Projects", imgSrc: "https://picsum.photos/seed/projects/250/200", route: "/projects" },
    { title: "Contact Me", imgSrc: "https://picsum.photos/seed/contact/250/200", route: "/contact-me" }
  ],
  developer: [
    { title: "Skills", imgSrc: "https://picsum.photos/seed/coding/250/200", route: "/skills" },
    { title: "Projects", imgSrc: "https://picsum.photos/seed/development/250/200", route: "/projects" },
    { title: "Certifications", imgSrc: "https://picsum.photos/seed/badge/250/200", route: "/certifications" },
    { title: "Experience", imgSrc: "https://picsum.photos/seed/work/250/200", route: "/work-experience" },
    { title: "Recommendations", imgSrc: "https://picsum.photos/seed/networking/250/200", route: "/recommendations" },
    { title: "Contact Me", imgSrc: "https://picsum.photos/seed/connect/250/200", route: "/contact-me" }
  ],
  stalker: [
    { title: "Recommendations", imgSrc: "https://picsum.photos/seed/networking/250/200", route: "/recommendations" },
    { title: "Contact Me", imgSrc: "https://picsum.photos/seed/call/250/200", route: "/contact-me" },
    { title: "Projects", imgSrc: "https://picsum.photos/seed/planning/250/200", route: "/projects" },
    { title: "Experience", imgSrc: "https://picsum.photos/seed/resume/250/200", route: "/work-experience" },
    { title: "Certifications", imgSrc: "https://picsum.photos/seed/achievements/250/200", route: "/certifications" },
  ],
  adventure: [
    { title: "Music", imgSrc: "https://picsum.photos/seed/music/250/200", route: "/music" },
    { title: "Projects", imgSrc: "https://picsum.photos/seed/innovation/250/200", route: "/projects" },
    { title: "Reading", imgSrc: "https://picsum.photos/seed/books/250/200", route: "/reading" },
    { title: "Contact Me", imgSrc: "https://picsum.photos/seed/connect/250/200", route: "/contact-me" },
    { title: "Certifications", imgSrc: "https://picsum.photos/seed/medal/250/200", route: "/certifications" }
  ]
};

function TopPicksRow({ profile }) {
  const topPicks = topPicksConfig[profile];

  const container = document.createElement('div');
  container.className = 'top-picks-row';

  const title = document.createElement('h2');
  title.className = 'row-title';
  title.textContent = `Today's Top Picks for ${profile}`;
  container.appendChild(title);

  const cardRow = document.createElement('div');
  cardRow.className = 'card-row';

  topPicks.forEach((pick, index) => {
    const card = document.createElement('div');
    card.className = 'pick-card';
    card.style.animationDelay = `${index * 0.2}s`;
    card.addEventListener('click', () => {
      window.location.href = pick.route;
    });

    const img = document.createElement('img');
    img.src = pick.imgSrc;
    img.alt = pick.title;
    img.className = 'pick-image';
    card.appendChild(img);

    const overlay = document.createElement('div');
    overlay.className = 'overlay';

    const label = document.createElement('div');
    label.className = 'pick-label';
    label.textContent = pick.title;
    overlay.appendChild(label);

    card.appendChild(overlay);
    cardRow.appendChild(card);
  });

  container.appendChild(cardRow);
  return container;
}

export default TopPicksRow;
