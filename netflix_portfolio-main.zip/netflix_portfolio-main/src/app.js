import NetflixTitle from './NetflixTitle.js';
import ProfilePage from './profilePage/profilePage.js';
import Browse from './browse/browse.js';
import WorkPermit from './pages/WorkPermit.js';
import WorkExperience from './pages/WorkExperience.js';
import Recommendations from './pages/Recommendations.js';
import Skills from './pages/Skills.js';
import Projects from './pages/Projects.js';
import ContactMe from './pages/ContactMe.js';
import Layout from './Layout.js';
import Music from './pages/Music.js';
import Reading from './pages/Reading.js';
import Blogs from './pages/Blogs.js';
import Certifications from './pages/Certifications.js';

const routes = {
  '/': NetflixTitle,
  '/browse': Browse,
  '/profile/:profileName': ProfilePage,
  '/work-permit': WorkPermit,
  '/work-experience': WorkExperience,
  '/recommendations': Recommendations,
  '/skills': Skills,
  '/projects': Projects,
  '/contact-me': ContactMe,
  '/music': Music,
  '/reading': Reading,
  '/blogs': Blogs,
  '/certifications': Certifications
};

function renderComponent(component) {
  const root = document.getElementById('root');
  root.innerHTML = component;
}

function navigateTo(path) {
  window.history.pushState({}, path, window.location.origin + path);
  const Component = routes[path];
  renderComponent(Component());
}

window.addEventListener('popstate', () => {
  const path = window.location.pathname;
  const Component = routes[path];
  renderComponent(Component());
});

document.addEventListener('DOMContentLoaded', () => {
  document.body.addEventListener('click', e => {
    if (e.target.matches('[data-link]')) {
      e.preventDefault();
      navigateTo(e.target.href);
    }
  });

  const path = window.location.pathname;
  const Component = routes[path];
  renderComponent(Component());
});
