import './Reading.css';
import atomicHabits from '../images/atomic_habits.jpg';
import richDadPoorDad from '../images/rich_dad_poor_dad.jpg';
import alchemist from '../images/alchemist.jpg';
import eatThatFrog from '../images/eat_that_frog.jpg';
import vijayanikiAidhuMetlu from '../images/vijayaniki_aidu_metlu.jpg';
import venneloAdapilla from '../images/vennelo_adapilla.jpeg';

const books = [
  {
    title: "Atomic Habits",
    author: "James Clear",
    imgSrc: atomicHabits,
    description: "A practical guide to building good habits and breaking bad ones.",
  },
  {
    title: "Rich Dad Poor Dad",
    author: "Robert Kiyosaki",
    imgSrc: richDadPoorDad,
    description: "An eye-opener on wealth, assets, and financial literacy.",
  },
  {
    title: "The Alchemist",
    author: "Paulo Coelho",
    imgSrc: alchemist,
    description: "A magical journey of following one's dreams.",
  },
  {
    title: "Eat That Frog",
    author: "Brian Tracy",
    imgSrc: eatThatFrog,
    description: "A motivational book on overcoming procrastination.",
  },
  {
    title: "Vijayaniki Aidhu Metlu",
    author: "Yandamoori Veerendranath",
    imgSrc: vijayanikiAidhuMetlu,
    description: "An inspirational Telugu book for personal growth.",
  },
  {
    title: "Vennelo Adapilla",
    author: "Yandamoori Veerendranath",
    imgSrc: venneloAdapilla,
    description: "A classic Telugu romantic novel that touches the heart.",
  },
];

function Reading() {
  const container = document.createElement('div');
  container.className = 'reading-container';

  const title = document.createElement('h2');
  title.className = 'reading-title';
  title.textContent = '📚 Books That Shaped My Journey';
  container.appendChild(title);

  const intro = document.createElement('p');
  intro.className = 'reading-intro';
  intro.textContent = 'These books have influenced my perspectives, motivation, and self-growth.';
  container.appendChild(intro);

  const grid = document.createElement('div');
  grid.className = 'books-grid';

  books.forEach((book, index) => {
    const card = document.createElement('div');
    card.className = 'book-card';
    card.style.setProperty('--delay', `${index * 0.1}s`);

    const img = document.createElement('img');
    img.src = book.imgSrc;
    img.alt = book.title;
    img.className = 'book-cover';
    card.appendChild(img);

    const info = document.createElement('div');
    info.className = 'book-info';

    const bookTitle = document.createElement('h3');
    bookTitle.className = 'book-title';
    bookTitle.textContent = book.title;
    info.appendChild(bookTitle);

    const author = document.createElement('h4');
    author.className = 'book-author';
    author.textContent = book.author;
    info.appendChild(author);

    const description = document.createElement('p');
    description.className = 'book-description';
    description.textContent = book.description;
    info.appendChild(description);

    card.appendChild(info);
    grid.appendChild(card);
  });

  container.appendChild(grid);
  return container;
}

export default Reading;
