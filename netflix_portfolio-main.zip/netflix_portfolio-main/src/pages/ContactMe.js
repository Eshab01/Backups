import './ContactMe.css';
import profilePic from '../images/sumanth.jpeg';
import { getContactMe } from '../queries/getContactMe.ts';

let userData = null;

async function fetchUserData() {
  userData = await getContactMe();
  updateContact();
}

function updateContact() {
  const container = document.querySelector('.contact-container');
  if (!container) return;

  const linkedinBadge = document.createElement('div');
  linkedinBadge.className = 'linkedin-badge-custom';

  const avatar = document.createElement('img');
  avatar.src = profilePic;
  avatar.alt = 'Sumanth Samala';
  avatar.className = 'badge-avatar';
  linkedinBadge.appendChild(avatar);

  const badgeContent = document.createElement('div');
  badgeContent.className = 'badge-content';

  const name = document.createElement('h3');
  name.className = 'badge-name';
  name.textContent = userData.name;
  badgeContent.appendChild(name);

  const title = document.createElement('p');
  title.className = 'badge-title';
  title.textContent = userData.title;
  badgeContent.appendChild(title);

  const description = document.createElement('p');
  description.className = 'badge-description';
  description.textContent = userData.summary;
  badgeContent.appendChild(description);

  const company = document.createElement('p');
  company.className = 'badge-company';
  company.textContent = userData.companyUniversity;
  badgeContent.appendChild(company);

  const linkedinLink = document.createElement('a');
  linkedinLink.href = userData.linkedinLink;
  linkedinLink.target = '_blank';
  linkedinLink.rel = 'noopener noreferrer';
  linkedinLink.className = 'badge-link';
  linkedinLink.innerHTML = '<FaLinkedin className="linkedin-icon" /> View Profile';
  badgeContent.appendChild(linkedinLink);

  linkedinBadge.appendChild(badgeContent);
  container.appendChild(linkedinBadge);

  const header = document.createElement('div');
  header.className = 'contact-header';
  header.innerHTML = '<p>I\'m always up for a chat or a coffee! Feel free to reach out.</p>';
  container.appendChild(header);

  const details = document.createElement('div');
  details.className = 'contact-details';

  const email = document.createElement('div');
  email.className = 'contact-item';
  email.innerHTML = `
    <FaEnvelope className="contact-icon" />
    <a href="mailto:${userData.email}" className="contact-link">${userData.email}</a>
  `;
  details.appendChild(email);

  const phone = document.createElement('div');
  phone.className = 'contact-item';
  phone.innerHTML = `
    <FaPhoneAlt className="contact-icon" />
    <a href="tel:${userData.phoneNumber}" className="contact-link">${userData.phoneNumber}</a>
  `;
  details.appendChild(phone);

  const coffee = document.createElement('div');
  coffee.className = 'contact-fun';
  coffee.innerHTML = `
    <p>Or catch up over a coffee ☕</p>
    <FaCoffee className="coffee-icon" />
  `;
  details.appendChild(coffee);

  container.appendChild(details);
}

function ContactMe() {
  const container = document.createElement('div');
  container.className = 'contact-container';

  if (!userData) {
    const loading = document.createElement('div');
    loading.textContent = 'Loading...';
    container.appendChild(loading);
    fetchUserData();
  } else {
    updateContact();
  }

  return container;
}

export default ContactMe;
