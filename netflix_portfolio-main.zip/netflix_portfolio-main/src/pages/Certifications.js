import './Certifications.css';
import { getCertifications } from '../queries/getCertifications.ts';

const iconData = {
  'udemy': '<SiUdemy />',
  'coursera': '<SiCoursera />',
  'ieee': '<SiIeee />',
  'university': '<FaUniversity />'
};

let certifications = [];

async function fetchCertifications() {
  certifications = await getCertifications();
  updateCertifications();
}

function updateCertifications() {
  const container = document.querySelector('.certifications-container');
  if (!container) return;

  const grid = document.createElement('div');
  grid.className = 'certifications-grid';

  certifications.forEach((cert, index) => {
    const link = document.createElement('a');
    link.href = cert.link;
    link.target = '_blank';
    link.rel = 'noopener noreferrer';
    link.className = 'certification-card';
    link.style.setProperty('--delay', `${index * 0.2}s`);

    const content = document.createElement('div');
    content.className = 'certification-content';

    const icon = document.createElement('div');
    icon.className = 'certification-icon';
    icon.innerHTML = iconData[cert.iconName] || '<FaUniversity />';
    content.appendChild(icon);

    const title = document.createElement('h3');
    title.textContent = cert.title;
    content.appendChild(title);

    const issuer = document.createElement('p');
    issuer.textContent = cert.issuer;
    content.appendChild(issuer);

    if (cert.issuedDate) {
      const date = document.createElement('span');
      date.className = 'issued-date';
      date.textContent = `Issued ${cert.issuedDate}`;
      content.appendChild(date);
    }

    link.appendChild(content);

    const linkIcon = document.createElement('div');
    linkIcon.className = 'certification-link animated-icon';
    linkIcon.innerHTML = '<FaExternalLinkAlt />';
    link.appendChild(linkIcon);

    grid.appendChild(link);
  });

  container.appendChild(grid);
}

function Certifications() {
  const container = document.createElement('div');
  container.className = 'certifications-container';

  if (certifications.length === 0) {
    const loading = document.createElement('div');
    loading.textContent = 'Loading...';
    container.appendChild(loading);
    fetchCertifications();
  } else {
    updateCertifications();
  }

  return container;
}

export default Certifications;
