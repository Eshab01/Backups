import './PlacesVisited.css';

function PlacesVisited() {
  const container = document.createElement('div');
  container.className = 'page-container';

  const title = document.createElement('h2');
  title.textContent = '🌍 Places Visited';
  container.appendChild(title);

  const description = document.createElement('p');
  description.textContent = 'A glimpse into my travel experiences and places I\'ve explored around the world.';
  container.appendChild(description);

  return container;
}

export default PlacesVisited;
