import './Recommendations.css';
import chrisProfilePic from '../images/chris.jpg';

function Recommendations() {
  const container = document.createElement('div');
  container.className = 'timeline-container';

  const card = document.createElement('div');
  card.className = 'recommendation-card';

  const header = document.createElement('div');
  header.className = 'recommendation-header';

  const profilePic = document.createElement('img');
  profilePic.src = chrisProfilePic;
  profilePic.alt = 'Chris Smith';
  profilePic.className = 'profile-pic';
  header.appendChild(profilePic);

  const headerContent = document.createElement('div');
  const name = document.createElement('h3');
  name.textContent = 'Chris Smith';
  headerContent.appendChild(name);

  const position = document.createElement('p');
  position.textContent = 'Head of Kajima Community';
  headerContent.appendChild(position);

  const date = document.createElement('p');
  date.className = 'date';
  date.textContent = 'October 24, 2024';
  headerContent.appendChild(date);

  header.appendChild(headerContent);
  card.appendChild(header);

  const body = document.createElement('div');
  body.className = 'recommendation-body';

  const paragraphs = [
    '✨ "It is with great pleasure that I write this reference for Sumanth, who worked for us as a software developer at Kajima from June 2023. Unfortunately, due to a change in the company’s structure, we have made the difficult decision to make their position redundant. This in no way reflects on their performance, which was consistently excellent.',
    'During their time with us, Sumanth demonstrated strong technical expertise, a passion for problem-solving, a willingness to learn, and a collaborative spirit that greatly contributed to our team’s success. They played a pivotal role in developing and maintaining key features of our software <strong>BookingsPlus</strong> and <strong>NHS Open Space</strong>, consistently delivering high-quality code while meeting project deadlines. Their ability to quickly adapt to new technologies and their proactive approach to finding innovative solutions set them apart."',
    '💼 "Sumanth also showed exceptional teamwork and communication skills, effectively collaborating with cross-functional teams, including product managers, designers, and QA. Their professionalism, positive attitude, and dedication to their work made them an asset to the team."',
    '🌟 "I have no doubt that Sumanth will be a valuable addition to any organization, and I wholeheartedly recommend them for any future opportunities."'
  ];

  paragraphs.forEach(text => {
    const p = document.createElement('p');
    p.innerHTML = text;
    body.appendChild(p);
  });

  card.appendChild(body);
  container.appendChild(card);

  return container;
}

export default Recommendations;
