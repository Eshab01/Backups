import './Music.css';
import albumCover1 from '../images/Hotelcalifornia.jpg';
import albumCover2 from '../images/ac-dc.jpg';
import albumCover3 from '../images/guns-n-roses.webp';

const favoriteGenres = ["Rock", "Classic Rock", "Hard Rock", "Blues", "Alternative"];
const favoriteAlbums = [
  { title: "Hotel California", artist: "The Eagles", imgSrc: albumCover1 },
  { title: "Back in Black", artist: "AC/DC", imgSrc: albumCover2 },
  { title: "Appetite for Destruction", artist: "Guns N' Roses", imgSrc: albumCover3 },
];

function Music() {
  const container = document.createElement('div');
  container.className = 'music-page';

  const quote = document.createElement('div');
  quote.className = 'quote';
  quote.innerHTML = '<p>“Rock and Roll isn’t a genre, it’s a way of life.” 🎸</p>';
  container.appendChild(quote);

  const genreSection = document.createElement('div');
  genreSection.className = 'genre-section';

  const genreTitle = document.createElement('h3');
  genreTitle.textContent = 'Explore by Genre';
  genreSection.appendChild(genreTitle);

  const genres = document.createElement('div');
  genres.className = 'genres';

  favoriteGenres.forEach((genre, index) => {
    const genreCard = document.createElement('div');
    genreCard.className = 'genre-card';
    genreCard.style.animationDelay = `${index * 0.2}s`;
    genreCard.textContent = genre;
    genres.appendChild(genreCard);
  });

  genreSection.appendChild(genres);
  container.appendChild(genreSection);

  const albumsSection = document.createElement('div');
  albumsSection.className = 'albums-section';

  const albumsTitle = document.createElement('h3');
  albumsTitle.textContent = 'Favorite Albums';
  albumsSection.appendChild(albumsTitle);

  const albums = document.createElement('div');
  albums.className = 'albums';

  favoriteAlbums.forEach((album, index) => {
    const albumCard = document.createElement('div');
    albumCard.className = 'album-card';
    albumCard.style.animationDelay = `${index * 0.3}s`;

    const img = document.createElement('img');
    img.src = album.imgSrc;
    img.alt = album.title;
    img.className = 'album-image';
    albumCard.appendChild(img);

    const details = document.createElement('div');
    details.className = 'album-details';

    const title = document.createElement('h4');
    title.textContent = album.title;
    details.appendChild(title);

    const artist = document.createElement('p');
    artist.textContent = `by ${album.artist}`;
    details.appendChild(artist);

    albumCard.appendChild(details);
    albums.appendChild(albumCard);
  });

  albumsSection.appendChild(albums);
  container.appendChild(albumsSection);

  return container;
}

export default Music;
