import './WorkExperience.css';
import { getTimeline } from '../queries/getTimeline.ts';

let timeLineData = null;

async function fetchTimelineData() {
  timeLineData = await getTimeline();
  updateTimeline();
}

function updateTimeline() {
  const container = document.querySelector('.timeline-container');
  if (!container) return;

  const timeline = document.createElement('div');
  timeline.className = 'timeline';

  timeLineData.forEach((item, index) => {
    const timelineItem = document.createElement('div');
    timelineItem.className = `timeline-item ${item.timelineType}`;

    const date = document.createElement('div');
    date.className = 'timeline-date';
    date.textContent = item.dateRange;
    timelineItem.appendChild(date);

    const content = document.createElement('div');
    content.className = 'timeline-content';

    if (item.timelineType === "work") {
      const title = document.createElement('h3');
      title.className = 'timeline-title';
      title.textContent = item.title;
      content.appendChild(title);

      const subtitle = document.createElement('h4');
      subtitle.className = 'timeline-subtitle';
      subtitle.textContent = item.name;
      content.appendChild(subtitle);

      const tech = document.createElement('p');
      tech.className = 'timeline-tech';
      tech.textContent = `🔧 ${item.techStack}`;
      content.appendChild(tech);
    } else {
      const title = document.createElement('h3');
      title.className = 'timeline-title';
      title.textContent = item.name;
      content.appendChild(title);

      const subtitle = document.createElement('h4');
      subtitle.className = 'timeline-subtitle';
      subtitle.textContent = item.title;
      content.appendChild(subtitle);
    }

    const summary = document.createElement('p');
    summary.textContent = item.summaryPoints;
    content.appendChild(summary);

    timelineItem.appendChild(content);
    timeline.appendChild(timelineItem);
  });

  const star = document.createElement('div');
  star.className = 'timeline-star';
  timeline.appendChild(star);

  container.appendChild(timeline);
}

function WorkExperience() {
  const container = document.createElement('div');
  container.className = 'timeline-container';

  const title = document.createElement('h2');
  title.className = 'timeline-title';
  title.textContent = '📅 Work Experience & Education Timeline';
  container.appendChild(title);

  if (!timeLineData) {
    const loading = document.createElement('div');
    loading.textContent = 'Loading...';
    container.appendChild(loading);
    fetchTimelineData();
  } else {
    updateTimeline();
  }

  return container;
}

export default WorkExperience;
