import './Projects.css';
import { getProjects } from '../queries/getProjects.ts';

let projects = [];

async function fetchProjects() {
  projects = await getProjects();
  updateProjects();
}

function updateProjects() {
  const container = document.querySelector('.projects-container');
  if (!container) return;

  const grid = document.createElement('div');
  grid.className = 'projects-grid';

  projects.forEach((project, index) => {
    const card = document.createElement('div');
    card.className = 'project-card';
    card.style.setProperty('--delay', `${index * 0.1}s`);

    const img = document.createElement('img');
    img.src = project.image.url;
    img.alt = project.title;
    img.className = 'project-image';
    card.appendChild(img);

    const details = document.createElement('div');
    details.className = 'project-details';

    const title = document.createElement('h3');
    title.textContent = project.title;
    details.appendChild(title);

    const description = document.createElement('p');
    description.textContent = project.description;
    details.appendChild(description);

    const techUsed = document.createElement('div');
    techUsed.className = 'tech-used';

    project.techUsed.split(', ').forEach(tech => {
      const badge = document.createElement('span');
      badge.className = 'tech-badge';
      badge.textContent = `🔧 ${tech}`;
      techUsed.appendChild(badge);
    });

    details.appendChild(techUsed);
    card.appendChild(details);
    grid.appendChild(card);
  });

  container.appendChild(grid);
}

function Projects() {
  const container = document.createElement('div');
  container.className = 'projects-container';

  if (projects.length === 0) {
    const loading = document.createElement('div');
    loading.textContent = 'Loading...';
    container.appendChild(loading);
    fetchProjects();
  } else {
    updateProjects();
  }

  return container;
}

export default Projects;
