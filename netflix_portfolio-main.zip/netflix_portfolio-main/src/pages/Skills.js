import './Skills.css';
import { getSkills } from '../queries/getSkills.ts';

let skillsData = [];

async function fetchSkills() {
  skillsData = await getSkills();
  updateSkills();
}

function updateSkills() {
  const container = document.querySelector('.skills-container');
  if (!container) return;

  const skillsByCategory = skillsData.reduce((acc, skill) => {
    if (!acc[skill.category]) acc[skill.category] = [];
    acc[skill.category].push(skill);
    return acc;
  }, {});

  Object.keys(skillsByCategory).forEach(category => {
    const categoryDiv = document.createElement('div');
    categoryDiv.className = 'skill-category';

    const title = document.createElement('h3');
    title.className = 'category-title';
    title.textContent = category;
    categoryDiv.appendChild(title);

    const grid = document.createElement('div');
    grid.className = 'skills-grid';

    skillsByCategory[category].forEach(skill => {
      const card = document.createElement('div');
      card.className = 'skill-card';

      const icon = document.createElement('div');
      icon.className = 'icon';
      icon.innerHTML = skill.icon || '<FaReact />';
      card.appendChild(icon);

      const name = document.createElement('h3');
      name.className = 'skill-name';

      skill.name.split('').forEach((letter, i) => {
        const span = document.createElement('span');
        span.className = 'letter';
        span.style.animationDelay = `${i * 0.05}s`;
        span.textContent = letter;
        name.appendChild(span);
      });

      card.appendChild(name);

      const description = document.createElement('p');
      description.className = 'skill-description';
      description.textContent = skill.description;
      card.appendChild(description);

      grid.appendChild(card);
    });

    categoryDiv.appendChild(grid);
    container.appendChild(categoryDiv);
  });
}

function Skills() {
  const container = document.createElement('div');
  container.className = 'skills-container';

  if (skillsData.length === 0) {
    const loading = document.createElement('div');
    loading.textContent = 'Loading...';
    container.appendChild(loading);
    fetchSkills();
  } else {
    updateSkills();
  }

  return container;
}

export default Skills;
