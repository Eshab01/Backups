import './Blogs.css';

const blogs = [
  {
    title: "Make Your Rails Console Look Better",
    platform: "Medium",
    icon: '<FaMedium />',
    link: "https://medium.com/@chintusamala96/make-your-rails-console-look-better-510988d40566",
    description: "Learn tips to customize your Rails console for a better experience.",
  },
  {
    title: "Docker Fundas - My Version",
    platform: "Medium",
    icon: '<FaMedium />',
    link: "https://medium.com/@chintusamala96/docker-fundas-my-version-7b9262bd90d4",
    description: "An introductory guide to Docker fundamentals from my perspective.",
  },
  {
    title: "Grape Gem in Ruby on Rails: Handling User Model and API Endpoint",
    platform: "Dev.to",
    icon: '<FaDev />',
    link: "https://dev.to/samalasumanth0262/grape-gem-in-ruby-on-rails-handling-user-model-and-api-endpoint-g6d",
    description: "A guide to using the Grape gem for API development in Ruby on Rails.",
  },
];

function Blogs() {
  const container = document.createElement('div');
  container.className = 'blogs-container';

  const title = document.createElement('h2');
  title.className = 'blogs-title';
  title.textContent = '✍️ My Blog Posts';
  container.appendChild(title);

  const intro = document.createElement('p');
  intro.className = 'blogs-intro';
  intro.textContent = 'A collection of my thoughts and tutorials on software development.';
  container.appendChild(intro);

  const grid = document.createElement('div');
  grid.className = 'blogs-grid';

  blogs.forEach((blog, index) => {
    const link = document.createElement('a');
    link.href = blog.link;
    link.target = '_blank';
    link.rel = 'noopener noreferrer';
    link.className = 'blog-card';
    link.style.setProperty('--delay', `${index * 0.2}s`);

    const icon = document.createElement('div');
    icon.className = 'blog-icon animated-icon';
    icon.innerHTML = blog.icon;
    link.appendChild(icon);

    const info = document.createElement('div');
    info.className = 'blog-info animated-text';

    const blogTitle = document.createElement('h3');
    blogTitle.className = 'blog-title';
    blogTitle.textContent = blog.title;
    info.appendChild(blogTitle);

    const description = document.createElement('p');
    description.className = 'blog-description';
    description.textContent = blog.description;
    info.appendChild(description);

    const platform = document.createElement('span');
    platform.className = 'blog-platform';
    platform.textContent = blog.platform;
    info.appendChild(platform);

    link.appendChild(info);
    grid.appendChild(link);
  });

  container.appendChild(grid);
  return container;
}

export default Blogs;
