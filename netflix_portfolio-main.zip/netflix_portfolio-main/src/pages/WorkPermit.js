import './WorkPermit.css';
import { getWorkPermit } from '../queries/getWorkPermit.ts';

let workPermitData = null;

async function fetchWorkPermitData() {
  workPermitData = await getWorkPermit();
  updateWorkPermit();
}

function updateWorkPermit() {
  const container = document.querySelector('.work-permit-container');
  if (!container) return;

  container.innerHTML = `
    <div className="work-permit-card">
      <h2 className="work-permit-headline">🎓 Work Permit</h2>
      <p className="work-permit-summary">
        I'm currently on a <strong>${workPermitData.visaStatus}</strong> 🛂, which allows me to work in the UK! 🇬🇧 My visa is valid until <strong>${new Date(workPermitData.expiryDate).toLocaleDateString()}</strong> 📅, giving me the opportunity to build valuable experience and grow my career here. 🌟
      </p>
      <p className="additional-info">${workPermitData.additionalInfo}</p>
    </div>
  `;
}

function WorkPermit() {
  const container = document.createElement('div');
  container.className = 'work-permit-container';

  if (!workPermitData) {
    container.textContent = 'Loading...';
    fetchWorkPermitData();
  } else {
    updateWorkPermit();
  }

  return container;
}

export default WorkPermit;
