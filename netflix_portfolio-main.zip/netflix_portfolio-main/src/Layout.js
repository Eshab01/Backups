import Navbar from './components/NavBar.js';

function Layout({ children }) {
  const container = document.createElement('div');

  const navbar = Navbar();
  container.appendChild(navbar);

  const content = document.createElement('div');
  content.className = 'content';
  content.appendChild(children);
  container.appendChild(content);

  return container;
}

export default Layout;
