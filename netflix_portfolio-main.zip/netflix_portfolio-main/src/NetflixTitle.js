import './NetflixTitle.css';
import netflixSound from './netflix-sound.mp3';
import logoImage from '../src/images/logo-2.png';

let isClicked = false;

function handlePlaySound() {
  const audio = new Audio(netflixSound);
  audio.play().catch(error => console.error("Audio play error:", error));
  isClicked = true;
  startAnimation();
}

function startAnimation() {
  const logo = document.querySelector('.netflix-logo');
  logo.classList.add('animate');
  
  setTimeout(() => {
    window.location.href = '/browse';
  }, 4000);
}

function NetflixTitle() {
  const container = document.createElement('div');
  container.className = 'netflix-container';
  container.addEventListener('click', handlePlaySound);

  const logo = document.createElement('img');
  logo.src = logoImage;
  logo.alt = 'Custom Logo';
  logo.className = 'netflix-logo';

  container.appendChild(logo);
  return container;
}

export default NetflixTitle;
