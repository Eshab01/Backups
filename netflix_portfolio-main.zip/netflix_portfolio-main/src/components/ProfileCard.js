import './ProfileCard.css';

function ProfileCard({ name, image, onClick }) {
  const card = document.createElement('div');
  card.className = 'profile-card';
  card.addEventListener('click', onClick);

  const imageContainer = document.createElement('div');
  imageContainer.className = 'image-container';

  const profileImage = document.createElement('img');
  profileImage.src = image;
  profileImage.alt = `${name} profile`;
  profileImage.className = 'profile-image';
  imageContainer.appendChild(profileImage);

  const profileName = document.createElement('h3');
  profileName.className = 'profile-name';
  profileName.textContent = name;

  card.appendChild(imageContainer);
  card.appendChild(profileName);
  return card;
}

export default ProfileCard;
