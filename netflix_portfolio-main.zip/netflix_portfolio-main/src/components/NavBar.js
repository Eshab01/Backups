import './Navbar.css';
import netflixLogo from '../images/logo-2.png';
import blueImage from '../images/blue.png';

function NavBar() {
  const nav = document.createElement('nav');
  nav.className = 'navbar';

  // Handle scroll event
  window.addEventListener('scroll', () => {
    if (window.scrollY > 80) {
      nav.classList.add('scrolled');
    } else {
      nav.classList.remove('scrolled');
    }
  });

  // Navbar left section
  const navbarLeft = document.createElement('div');
  navbarLeft.className = 'navbar-left';

  const logoLink = document.createElement('a');
  logoLink.href = '/';
  logoLink.className = 'navbar-logo';

  const logoImg = document.createElement('img');
  logoImg.src = netflixLogo;
  logoImg.alt = 'Netflix';
  logoLink.appendChild(logoImg);

  const links = document.createElement('ul');
  links.className = 'navbar-links';

  const linksData = [
    { text: 'Home', href: '/browse' },
    { text: 'Professional', href: '/work-experience' },
    { text: 'Skills', href: '/skills' },
    { text: 'Projects', href: '/projects' },
    { text: 'Hire Me', href: '/contact-me' }
  ];

  linksData.forEach(link => {
    const li = document.createElement('li');
    const a = document.createElement('a');
    a.href = link.href;
    a.textContent = link.text;
    li.appendChild(a);
    links.appendChild(li);
  });

  navbarLeft.appendChild(logoLink);
  navbarLeft.appendChild(links);

  // Navbar right section
  const navbarRight = document.createElement('div');
  navbarRight.className = 'navbar-right';

  // Hamburger menu
  const hamburger = document.createElement('div');
  hamburger.className = 'hamburger';
  hamburger.addEventListener('click', toggleSidebar);

  for (let i = 0; i < 3; i++) {
    hamburger.appendChild(document.createElement('div'));
  }

  const profileImg = document.createElement('img');
  profileImg.src = blueImage;
  profileImg.alt = 'Profile';
  profileImg.className = 'profile-icon';
  profileImg.addEventListener('click', () => {
    window.location.href = '/browse';
  });

  navbarRight.appendChild(hamburger);
  navbarRight.appendChild(profileImg);

  nav.appendChild(navbarLeft);
  nav.appendChild(navbarRight);

  // Sidebar overlay
  const sidebarOverlay = document.createElement('div');
  sidebarOverlay.className = 'sidebar-overlay';
  sidebarOverlay.addEventListener('click', closeSidebar);

  // Sidebar
  const sidebar = document.createElement('div');
  sidebar.className = 'sidebar';

  const sidebarLogo = document.createElement('div');
  sidebarLogo.className = 'sidebar-logo';

  const sidebarLogoImg = document.createElement('img');
  sidebarLogoImg.src = netflixLogo;
  sidebarLogoImg.alt = 'Netflix Logo';
  sidebarLogo.appendChild(sidebarLogoImg);

  const sidebarLinks = document.createElement('ul');
  const sidebarLinksData = [
    { text: 'Home', href: '/browse', icon: 'FaHome' },
    { text: 'Professional', href: '/work-experience', icon: 'FaBriefcase' },
    { text: 'Skills', href: '/skills', icon: 'FaTools' },
    { text: 'Projects', href: '/projects', icon: 'FaProjectDiagram' },
    { text: 'Hire Me', href: '/contact-me', icon: 'FaEnvelope' }
  ];

  sidebarLinksData.forEach(link => {
    const li = document.createElement('li');
    const a = document.createElement('a');
    a.href = link.href;
    a.textContent = link.text;
    a.addEventListener('click', closeSidebar);
    li.appendChild(a);
    sidebarLinks.appendChild(li);
  });

  sidebar.appendChild(sidebarLogo);
  sidebar.appendChild(sidebarLinks);

  // Helper functions
  function toggleSidebar() {
    sidebar.classList.toggle('open');
    sidebarOverlay.classList.toggle('open');
  }

  function closeSidebar() {
    sidebar.classList.remove('open');
    sidebarOverlay.classList.remove('open');
  }

  // Append all elements
  document.body.appendChild(sidebarOverlay);
  document.body.appendChild(sidebar);

  return nav;
}

export default NavBar;
