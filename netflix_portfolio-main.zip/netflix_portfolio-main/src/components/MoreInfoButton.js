import './MoreInfoButton.css';

function MoreInfoButton({ onClick, label = "More Info" }) {
  const button = document.createElement('button');
  button.className = 'more-info-button';
  button.type = 'button';
  button.addEventListener('click', onClick);

  const iconContainer = document.createElement('div');
  iconContainer.className = 'icon-container';

  const svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
  svg.setAttribute('xmlns', 'http://www.w3.org/2000/svg');
  svg.setAttribute('fill', 'none');
  svg.setAttribute('role', 'img');
  svg.setAttribute('viewBox', '0 0 24 24');
  svg.setAttribute('width', '24');
  svg.setAttribute('height', '24');
  svg.setAttribute('aria-hidden', 'true');

  const path = document.createElementNS('http://www.w3.org/2000/svg', 'path');
  path.setAttribute('fill-rule', 'evenodd');
  path.setAttribute('clip-rule', 'evenodd');
  path.setAttribute('d', 'M12 2C6.47715 2 2 6.47715 2 12C2 17.5228 6.47715 22 12 22C17.5228 22 22 17.5228 22 12C22 6.47715 17.5228 2 12 2ZM0 12C0 5.37258 5.37258 0 12 0C18.6274 0 24 5.37258 24 12C24 18.6274 18.6274 24 12 24C5.37258 24 0 18.6274 0 12ZM13 10V18H11V10H13ZM12 8.5C12.8284 8.5 13.5 7.82843 13.5 7C13.5 6.17157 12.8284 5.5 12 5.5C11.1716 5.5 10.5 6.17157 10.5 7C10.5 7.82843 11.1716 8.5 12 8.5Z');
  path.setAttribute('fill', 'white');
  svg.appendChild(path);
  iconContainer.appendChild(svg);

  const spacer = document.createElement('div');
  spacer.className = 'spacer';

  const labelSpan = document.createElement('span');
  labelSpan.className = 'label';
  labelSpan.textContent = label;

  button.appendChild(iconContainer);
  button.appendChild(spacer);
  button.appendChild(labelSpan);
  return button;
}

export default MoreInfoButton;
